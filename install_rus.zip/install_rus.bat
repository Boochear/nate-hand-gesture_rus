@echo off
chcp 65001 >nul
setlocal

echo Установка русификатора Nate Hand Gesture Demo
echo.
set /p "STEAM_DRIVE=Введи букву диска, где стоит Steam (например C): "
if "%STEAM_DRIVE:~1,1%"==":" set "STEAM_DRIVE=%STEAM_DRIVE:~0,1%"
set "STEAM_DRIVE=%STEAM_DRIVE%:"

set "DATA_DIR=%STEAM_DRIVE%\SteamLibrary\steamapps\common\Nate Hand Gesture Demo\nate hand gesture_Data"
set "MANAGED_DIR=%DATA_DIR%\Managed"
set "SRC_DIR=%~dp0"

echo Источник: %SRC_DIR%
echo Data:     %DATA_DIR%
echo Managed:  %MANAGED_DIR%
echo.

if not exist "%DATA_DIR%" (
    echo [ОШИБКА] Не найдена папка Data: %DATA_DIR%
    echo Проверь, правильно ли введена буква диска.
    pause
    exit /b 1
)

echo Копирую все файлы, кроме Assembly-CSharp.dll...
robocopy "%SRC_DIR:~0,-1%" "%DATA_DIR%" /E /XF Assembly-CSharp.dll install_rus.bat /NFL /NDL /NJH /NJS

echo.
if exist "%SRC_DIR%Assembly-CSharp.dll" (
    echo Копирую Assembly-CSharp.dll в Managed...
    copy /Y "%SRC_DIR%Assembly-CSharp.dll" "%MANAGED_DIR%\Assembly-CSharp.dll" >nul
    echo Готово.
) else (
    echo [ВНИМАНИЕ] Assembly-CSharp.dll не найден рядом со скриптом, пропущено.
)

echo.
echo Установка завершена.
pause
